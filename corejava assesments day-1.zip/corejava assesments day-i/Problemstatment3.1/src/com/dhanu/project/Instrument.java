package com.dhanu.project;



	public abstract class Instrument {
		public abstract void play();
	}


