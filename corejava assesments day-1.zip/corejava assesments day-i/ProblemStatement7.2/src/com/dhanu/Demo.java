package com.dhanu;



	class StudentDemo extends Exception
	{
	     public String validname()
	     {
	          return ("Name is not Valid..Please ReEnter the Name");
	     }
	}

